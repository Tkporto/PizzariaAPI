public class Pizza
{
    public int Id { get; set; }
    public string? Sabor { get; set; }
    public double Valor { get; set; }

}
